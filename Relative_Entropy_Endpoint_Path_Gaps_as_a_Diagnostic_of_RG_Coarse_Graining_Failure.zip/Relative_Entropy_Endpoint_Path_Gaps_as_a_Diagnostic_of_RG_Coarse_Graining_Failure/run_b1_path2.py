#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
B1 (Path-2) one-click runner (journal-ready plot labels):
- Reads main.pdf (same folder) to confirm the QED one-loop b-structure.
- Locks an illustrative viewpoint/protocol instance (since sigma/u0 are not numerically fixed in Ch.7).
- Computes Gamma_geo(T) by the closed-form under constant diagonal metric (Appendix-B closed form).
- Runs Sec.8.4 decision rule: one-sided lower CI + Bonferroni correction over a T-grid.
- Writes:
    fig_gamma_geo_ci.csv
    fig_gamma_geo_ci.png
    fig_gamma_geo_ci.pdf
    run_lock.txt
"""

from __future__ import annotations

import os
import math
from dataclasses import dataclass
from typing import Tuple, List

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import matplotlib as mpl
mpl.rcParams["pdf.fonttype"] = 42
mpl.rcParams["ps.fonttype"] = 42

try:
    import PyPDF2
except ImportError as e:
    raise SystemExit("Missing dependency PyPDF2. Run: python -m pip install PyPDF2") from e


# -----------------------------
# 0) PDF helpers (best-effort)
# -----------------------------
def extract_text_from_pdf(pdf_path: str, max_pages: int = 30) -> str:
    reader = PyPDF2.PdfReader(pdf_path)
    pages = min(len(reader.pages), max_pages)
    chunks = []
    for i in range(pages):
        chunks.append(reader.pages[i].extract_text() or "")
    return "\n".join(chunks)


def infer_b_min_from_pdf(pdf_path: str) -> Tuple[float, str]:
    """
    Paper structure (Eq. 6.2): b = (2/(3π)) * Σ_{f∈active} n_f Q_f^2 > 0.
    Since Σ(...) is not numerically fixed in the main text, lock the minimal illustrative case Σ=1:
      b_min = 2/(3π).
    """
    bmin = 2.0 / (3.0 * math.pi)
    try:
        txt = extract_text_from_pdf(pdf_path, max_pages=40)
        hit = (
            ("2/(3" in txt)
            or ("2/(3π" in txt)
            or ("2/(3pi" in txt.lower())
            or ("2/(3\\pi" in txt)
        )
        if hit:
            note = (
                "Found QED one-loop structure b ∝ 2/(3π) in PDF; "
                "locked Σ_active n_f Q_f^2 = 1 (minimal), hence b_min=2/(3π)."
            )
        else:
            note = (
                "Could not robustly match '2/(3π)' in extracted PDF text; "
                "still locked Σ_active n_f Q_f^2 = 1 (minimal), hence b_min=2/(3π)."
            )
        return bmin, note
    except Exception:
        return bmin, "PDF read failed; locked Σ_active n_f Q_f^2 = 1 (minimal), hence b_min=2/(3π)."


def infer_p_default_from_pdf(pdf_path: str) -> Tuple[float, str]:
    """
    Paper structure: p := d-4 > 0 for an irrelevant direction (Ch.7 / App.C).
    Since no numeric p is fixed in Ch.7, default-lock p=2 (d=6 representative).
    """
    p = 2.0
    note = "Locked p=2 (d=6 representative irrelevant direction; p=d-4>0 as in Ch.7/App.C)."
    return p, note


# -----------------------------
# 1) Closed-form Gamma_geo(T) under constant diagonal metric (Appendix-B form)
# Reduced parameters:
#   a = b/sigma_theta > 0
#   r = u0/sigma_u     (can be signed)
#   p = d-4 > 0
# Let c = p*r.
# ΔII(T) = a T + (1/p)[ sqrt(a^2+c^2) - sqrt(a^2 + c^2 e^{-2pT})
#                      + a ln( (a + sqrt(a^2 + c^2 e^{-2pT}))/(a + sqrt(a^2+c^2)) ) ]
# d_I(T) = sqrt( (aT)^2 + (r(1-e^{-pT}))^2 )
# Γ_geo(T) = ΔII(T) - d_I(T)
# -----------------------------
def gamma_geo_closed_form(T: float, *, p: float, a: float, r: float) -> float:
    if T <= 0:
        return 0.0
    if not (p > 0 and a > 0):
        return float("nan")

    c = p * r
    pT = p * T
    if pT < 1e-12:
        return 0.0

    s0 = math.sqrt(a * a + c * c)
    sT = math.sqrt(a * a + (c * c) * math.exp(-2.0 * pT))
    log_arg = (a + sT) / (a + s0)
    DeltaII = a * T + (1.0 / p) * (s0 - sT + a * math.log(log_arg))
    dI = math.sqrt((a * T) ** 2 + (r * (1.0 - math.exp(-pT))) ** 2)
    g = DeltaII - dI
    return max(g, 0.0)


# -----------------------------
# 2) A “run-through” protocol lock (no user input required)
# -----------------------------
@dataclass(frozen=True)
class RunLock:
    # Physics-side / model-side
    b: float
    p: float

    # Viewpoint/protocol-side lock in reduced coordinates:
    # a := b/sigma_theta ; r := u0/sigma_u
    a: float
    r: float

    # Sec.8.4 decision rule locks
    alpha_global: float
    mc_reps: int

    # Minimal explicit uncertainty model (stand-in for protocol_ε propagation)
    a_sd: float
    r_sd: float

    # T-grid for the scan
    T_grid: Tuple[float, ...]


def default_run_lock(pdf_path: str) -> Tuple[RunLock, List[str]]:
    notes: List[str] = []

    bmin, b_note = infer_b_min_from_pdf(pdf_path)
    notes.append(b_note)

    p, p_note = infer_p_default_from_pdf(pdf_path)
    notes.append(p_note)

    # Core illustrative lock (dimensionless):
    a = 1.0
    r = 1.0

    alpha = 0.05
    mc_reps = 8000

    # Uncertainty magnitudes (explicit, reproducible; can be justified as protocol resolution)
    a_sd = 0.05
    r_sd = 0.10

    T_grid = (0.20, 0.40, 0.70, 1.00, 1.50, 2.00, 2.60, 3.20, 3.80, 4.50, 5.00)

    lock = RunLock(
        b=bmin,
        p=p,
        a=a,
        r=r,
        alpha_global=alpha,
        mc_reps=mc_reps,
        a_sd=a_sd,
        r_sd=r_sd,
        T_grid=T_grid,
    )
    return lock, notes


# -----------------------------
# 3) Sec.8.4: one-sided lower CI + Bonferroni correction
# -----------------------------
def one_sided_lower_ci_bonferroni(
    rng: np.random.Generator,
    T_grid: np.ndarray,
    *,
    p: float,
    a: float,
    r: float,
    mc_reps: int,
    alpha_global: float,
    a_sd: float,
    r_sd: float,
) -> Tuple[np.ndarray, np.ndarray]:
    m = len(T_grid)
    alpha_j = alpha_global / m  # Bonferroni

    g_hat = np.array([gamma_geo_closed_form(float(T), p=p, a=a, r=r) for T in T_grid], dtype=float)

    sims = np.empty((mc_reps, m), dtype=float)
    for k in range(mc_reps):
        a_k = float(a + rng.normal(0.0, a_sd))
        r_k = float(r + rng.normal(0.0, r_sd))
        if a_k <= 0:
            sims[k, :] = np.nan
            continue
        sims[k, :] = np.array(
            [gamma_geo_closed_form(float(T), p=p, a=a_k, r=r_k) for T in T_grid],
            dtype=float,
        )

    sims = sims[np.isfinite(sims).all(axis=1)]
    if sims.shape[0] < max(100, mc_reps // 10):
        raise RuntimeError("Too many invalid Monte Carlo draws (a<=0). Reduce a_sd or increase a.")

    Lcorr = np.quantile(sims, alpha_j, axis=0)
    return g_hat, Lcorr


def status_label(Lcorr: float, eps: float = 1e-12) -> str:
    return "MISMATCH" if (np.isfinite(Lcorr) and Lcorr > eps) else "ADMISSIBLE"


# -----------------------------
# 4) Main: run, save CSV, save PNG/PDF, save lock file
# -----------------------------
def main():
    pdf_path = "main.pdf"
    if not os.path.exists(pdf_path):
        raise SystemExit("Cannot find main.pdf in current folder. Put this script next to main.pdf and rerun.")

    lock, notes = default_run_lock(pdf_path)

    T_grid = np.array(lock.T_grid, dtype=float)
    rng = np.random.default_rng(0)

    # 1D baseline (r=0): Γ_geo ≡ 0
    gamma1d_hat = np.zeros_like(T_grid)
    gamma1d_Lcorr = np.zeros_like(T_grid)

    # 2D EFT: point estimate + corrected one-sided lower CI
    gamma2d_hat, gamma2d_Lcorr = one_sided_lower_ci_bonferroni(
        rng,
        T_grid,
        p=lock.p,
        a=lock.a,
        r=lock.r,
        mc_reps=lock.mc_reps,
        alpha_global=lock.alpha_global,
        a_sd=lock.a_sd,
        r_sd=lock.r_sd,
    )

    status2d = [status_label(float(L)) for L in gamma2d_Lcorr]

    df = pd.DataFrame(
        {
            "T": T_grid,
            "gamma1d_hat": gamma1d_hat,
            "gamma1d_Lcorr": gamma1d_Lcorr,
            "gamma2d_hat": gamma2d_hat,
            "gamma2d_Lcorr": gamma2d_Lcorr,
            "status2d": status2d,
        }
    )

    # Save CSV
    csv_out = "fig_gamma_geo_ci.csv"
    df.to_csv(csv_out, index=False)

    # Save lock note file
    lock_out = "run_lock.txt"
    with open(lock_out, "w", encoding="utf-8") as f:
        f.write("B1 Path-2 run lock (auto, no user input)\n")
        f.write("--------------------------------------------------\n")
        for n in notes:
            f.write(f"- {n}\n")
        f.write("\nLocked numeric instance used for this run:\n")
        f.write(f"  b_min = {lock.b:.10f}  (using Σ_active n_f Q_f^2 = 1)\n")
        f.write(f"  p     = {lock.p}\n")
        f.write(f"  a     = {lock.a}    (dimensionless a=b/σθ)\n")
        f.write(f"  r     = {lock.r}    (dimensionless r=u0/σu)\n")
        f.write("\nSec.8.4 decision locks:\n")
        f.write(f"  alpha_global = {lock.alpha_global}\n")
        f.write(f"  Bonferroni over m={len(lock.T_grid)} windows: alpha_j = alpha/m\n")
        f.write(f"  MonteCarlo reps = {lock.mc_reps}\n")
        f.write("\nUncertainty model (minimal explicit stand-in for protocol_ε propagation):\n")
        f.write(f"  a_hat ~ N(a, a_sd^2) with a_sd = {lock.a_sd}\n")
        f.write(f"  r_hat ~ N(r, r_sd^2) with r_sd = {lock.r_sd}\n")
        f.write("\nT-grid:\n")
        f.write("  " + ", ".join(str(x) for x in lock.T_grid) + "\n")

    # -----------------------------
    # Plot (Matplotlib) — journal-facing labels
    # -----------------------------
    SHOW_BASELINE_CI = False   # baseline CI is exactly 0 in this minimal implementation
    SHOW_STATUS_MARKERS = True # keep markers; they are now monochrome and unambiguous

    plt.figure(figsize=(9.2, 5.0))

    # Baseline
    plt.plot(
        T_grid,
        gamma1d_hat,
        linestyle="--",
        linewidth=2.4,
        label=r"1D baseline: $\widehat{\Gamma}_{\mathrm{geo}}$",
    )
    if SHOW_BASELINE_CI:
        plt.plot(
            T_grid,
            gamma1d_Lcorr,
            linestyle=":",
            linewidth=2.0,
            label=r"1D Bonferroni-corrected one-sided lower CI",
        )

    # 2D EFT estimate + corrected one-sided lower CI
    plt.plot(
        T_grid,
        gamma2d_hat,
        linewidth=3.0,
        label=r"2D EFT: $\widehat{\Gamma}_{\mathrm{geo}}$",
    )
    plt.plot(
        T_grid,
        gamma2d_Lcorr,
        linestyle="--",
        linewidth=3.0,
        label=r"2D Bonferroni-corrected one-sided lower CI",
    )

       # No status markers in the journal-facing figure (avoid redundant semantics on the plot)

    plt.axhline(0.0, linewidth=1.0)
    plt.xlabel(r"Window length $T$")
    plt.ylabel(r"$\Gamma_{\mathrm{geo}}(T)$")
    plt.legend()
    plt.tight_layout()

    png_out = "fig_gamma_geo_ci.png"
    pdf_out = "fig_gamma_geo_ci.pdf"
    plt.savefig(png_out, dpi=240)
    plt.savefig(pdf_out, bbox_inches="tight")
    plt.close()

    # Console summary
    print(f"Wrote: {csv_out}")
    print(f"Wrote: {png_out}")
    print(f"Wrote: {pdf_out}")
    print(f"Wrote: {lock_out}")
    print("\nPreview (first rows):")
    print(df.head(8).to_string(index=False))


if __name__ == "__main__":
    main()
